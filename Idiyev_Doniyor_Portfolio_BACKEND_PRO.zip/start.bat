@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js topilmadi. Node.js o'rnating: https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules\express npm install
set ADMIN_KEY=doniyor-admin
start "Portfolio" cmd /k "node server.js"
timeout /t 2 >nul
start "" http://localhost:3000
start "" http://localhost:3000/admin
