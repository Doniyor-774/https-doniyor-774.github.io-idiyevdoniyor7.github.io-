const express = require('express');
const path = require('path');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'backend', 'data');
const MSG_FILE = path.join(DATA_DIR, 'messages.json');
const SERVICES_FILE = path.join(DATA_DIR, 'services.json');
const ADMIN_KEY = process.env.ADMIN_KEY || 'doniyor-admin';

fs.mkdirSync(DATA_DIR, { recursive: true });
for (const [file, initial] of [[MSG_FILE,'[]'],[SERVICES_FILE,'[]']]) if (!fs.existsSync(file)) fs.writeFileSync(file, initial);
app.use(express.json({limit:'50kb'}));
app.use(express.urlencoded({extended:true}));
app.use(express.static(ROOT));

function read(file){try{return JSON.parse(fs.readFileSync(file,'utf8'))}catch{return []}}
function write(file,data){fs.writeFileSync(file,JSON.stringify(data,null,2),'utf8')}
function admin(req,res,next){
  if ((req.headers['x-admin-key']||req.query.key) !== ADMIN_KEY) return res.status(401).json({ok:false,error:'Admin kaliti noto‘g‘ri.'});
  next();
}

app.get('/api/health',(req,res)=>res.json({ok:true,service:'portfolio-backend'}));
app.get('/api/services',(req,res)=>res.json({ok:true,services:read(SERVICES_FILE).filter(x=>x.active!==false)}));
app.get('/api/admin/services',admin,(req,res)=>res.json({ok:true,services:read(SERVICES_FILE)}));
app.post('/api/admin/services',admin,(req,res)=>{
  const {icon='🔧',title,description,active=true}=req.body||{};
  if(!title||!description) return res.status(400).json({ok:false,error:'Nomi va tavsif kerak.'});
  const items=read(SERVICES_FILE); const item={id:Date.now(),icon:String(icon).slice(0,8),title:String(title).trim().slice(0,100),description:String(description).trim().slice(0,500),active:Boolean(active)};
  items.push(item); write(SERVICES_FILE,items); res.json({ok:true,service:item});
});
app.put('/api/admin/services/:id',admin,(req,res)=>{
  const id=Number(req.params.id), items=read(SERVICES_FILE), i=items.findIndex(x=>x.id===id);
  if(i<0) return res.status(404).json({ok:false,error:'Xizmat topilmadi.'});
  items[i]={...items[i],icon:String(req.body.icon??items[i].icon).slice(0,8),title:String(req.body.title??items[i].title).trim().slice(0,100),description:String(req.body.description??items[i].description).trim().slice(0,500),active:req.body.active!==undefined?Boolean(req.body.active):items[i].active};
  write(SERVICES_FILE,items); res.json({ok:true,service:items[i]});
});
app.delete('/api/admin/services/:id',admin,(req,res)=>{
  const id=Number(req.params.id), items=read(SERVICES_FILE), next=items.filter(x=>x.id!==id);
  if(next.length===items.length) return res.status(404).json({ok:false,error:'Xizmat topilmadi.'});
  write(SERVICES_FILE,next); res.json({ok:true});
});

app.post('/api/contact',(req,res)=>{
  const {name,email,message}=req.body||{};
  if(!name||!email||!message) return res.status(400).json({ok:false,error:"Barcha maydonlarni to‘ldiring."});
  const messages=read(MSG_FILE); messages.push({id:Date.now(),name:String(name).trim().slice(0,100),email:String(email).trim().slice(0,160),message:String(message).trim().slice(0,3000),createdAt:new Date().toISOString(),read:false}); write(MSG_FILE,messages);
  res.json({ok:true,message:'Xabaringiz muvaffaqiyatli yuborildi.'});
});
app.get('/api/admin/messages',admin,(req,res)=>res.json({ok:true,messages:read(MSG_FILE).reverse()}));
app.patch('/api/admin/messages/:id',admin,(req,res)=>{const id=Number(req.params.id),a=read(MSG_FILE),i=a.findIndex(x=>x.id===id);if(i<0)return res.status(404).json({ok:false});a[i].read=true;write(MSG_FILE,a);res.json({ok:true})});
app.delete('/api/admin/messages/:id',admin,(req,res)=>{const id=Number(req.params.id),a=read(MSG_FILE),n=a.filter(x=>x.id!==id);write(MSG_FILE,n);res.json({ok:true})});

app.get('/admin',(req,res)=>res.sendFile(path.join(ROOT,'admin.html')));
app.get('*',(req,res)=>res.sendFile(path.join(ROOT,'index.html')));
app.listen(PORT,()=>console.log(`Portfolio: http://localhost:${PORT}\nAdmin: http://localhost:${PORT}/admin`));
