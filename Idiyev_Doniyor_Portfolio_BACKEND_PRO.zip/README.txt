IDIYEV DONIYOR PORTFOLIO — BACKEND + ADMIN

Ishga tushirish:
1. start.bat ni 2 marta bosing.
2. Sayt: http://localhost:3000
3. Backend admin panel: http://localhost:3000/admin
4. Admin kalit: doniyor-admin

Admin panelda:
- Xizmat qo‘shish, tahrirlash, o‘chirish
- Xizmatlar saytga avtomatik chiqadi
- Kelgan kontakt xabarlarini ko‘rish
- Xabarni o‘qildi deb belgilash va o‘chirish

Xizmatlar backend/data/services.json da saqlanadi.
Xabarlar backend/data/messages.json da saqlanadi.

Hostingga chiqarishda ADMIN_KEY ni alohida kuchli qiymatga o‘zgartiring.
