CSS va surat index.html ichida ham saqlangan, shuning uchun dizayn va rasm yo‘qolmaydi. index.html ni Chrome/Edge bilan oching.
Telefon: +998-99-774-80-24
Email: idiyevdoniyor7@gmail.com